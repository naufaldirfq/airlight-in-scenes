# skydetector
A Python implementation of [Sky Region Detection in a Single Image for Autonomous Ground Robot Navigation (Shen and Wang, 2013)](https://journals.sagepub.com/doi/full/10.5772/56884)

Note: The [LICENSE](LICENSE) only applies to the python implementation.  I have no rights to the underlying paper, the quoted sections in the notebook are for context only.
